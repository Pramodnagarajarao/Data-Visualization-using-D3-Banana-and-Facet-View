import sys
import json
import os
from random import randint

txt=open("huge.json",'r',errors='ignore')


js=json.load(txt)
#print(js)
n=js['response']['numFound']
print(n)
d=[]
c=0
txt2=open("miserables.json",'w')
txt2.write("{\"nodes\":[\n")
for x in range(0,n):
	#print(js['response']['docs'][x])
	temp=js['response']['docs'][x]
	item=temp['clavin_location']
	#print(item)
	if item[0]=='Arctic' and len(item)==1 and x==n-1:
		#d.append(item[0])
		c=c+1
		#txt2.write("{\"name\":\""+str(js['response']['docs'][x])+"\",\"group\":"+str(d.index(js['response']['docs'][x]['clavin_location'][0]))+"},\n")
		txt2.write("{\"name\":\""+str(js['response']['docs'][x]['clavin_latitude'][0])+","+str(js['response']['docs'][x]['clavin_longitude'][0])+","+os.path.basename(str(js['response']['docs'][x]['id']))+"\",\"group\":"+str(randint(1,7))+"}\n")
	elif item[0]=='Arctic' and len(item)==1:
		#d.append(item[0])
		c=c+1
		#txt2.write("{\"name\":\""+str(js['response']['docs'][x])+"\",\"group\":"+str(d.index(js['response']['docs'][x]['clavin_location'][0]))+"},\n")
		txt2.write("{\"name\":\""+str(js['response']['docs'][x]['clavin_latitude'][0])+","+str(js['response']['docs'][x]['clavin_longitude'][0])+","+os.path.basename(str(js['response']['docs'][x]['id']))+"\",\"group\":"+str(randint(1,7))+"},\n")





	



txt2.write("\n],\n\"links\":[\n")

for x in range(0,150):
	if x==149:
		txt2.write("{\"source\":"+str(randint(1,c-1))+",\"target\":"+str(randint(1,c-1))+",\"value\":"+str(randint(0,50))+"}\n")
	else:
		txt2.write("{\"source\":"+str(randint(1,c-1))+",\"target\":"+str(randint(1,c-1))+",\"value\":"+str(randint(0,50))+"},\n")

txt2.write("]}")
txt.close()
txt2.close()
