import sys
import json
import os
from random import randint

txt=open("hugewithdate.json",'r',errors='ignore')
txt2=open("map.json",'w')
js=json.load(txt)
#print(js)
n=js['response']['numFound']
print(n)
d=[]
c=0

'''[{
          ID: 'RDS-37',
          radius: 8,
          cType: "text/html",
          fillKey: 'RUS',
          date: '1955-11-22',
          latitude: -80,
          longitude: 0,
          fillOpacity: 10

        }'''
txt2.write("[\n")


for x in range(0,n):
	#print(js['response']['docs'][x])
	temp=js['response']['docs'][x]
	#print(temp)
	i=os.path.basename(temp['id'])
	d=temp['date_created'].split(' ')[0]
	#print(i)
	val=i.rsplit('.',1)
	txt2.write("{ID: \""+i+"\",\nradius: "+str(randint(0,8))+",\ncType: \""+val[-1]+"\",\nfillKey:'RUS',\ndate: '"+d+"',\nlatitude: "+temp['clavin_latitude'][0]+",\nlongitude: "+temp['clavin_longitude'][0]+",\nfillOpacity:10\n},")

	#break
txt2.write("\n];")
txt2.close()

