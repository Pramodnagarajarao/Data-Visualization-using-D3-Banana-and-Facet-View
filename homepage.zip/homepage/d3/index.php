<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
//Based on apache server configured
function buildexec($cmd){
	//Building te json, after search. Make sure PHP is configured to enable documents to be written to htdocs folder
		exec ("python3 ../d3/date.py");
		exec ("python3 ../d3/force.py")
		exec ("python3 ../d3/instruments.py")
		exec ("python3 ../d3/month.py")
		exec ("python3 ../d3/parse.py")
		exec ("python3 ../d3/year.py")
		exec ("python3 ../d3/map.py")
		
		loadjson();
}

function lodjson(){
	exec ("python3");
	exec ("json.load(fs.out,force.json)");
	exec ("json.load(map.out,map.json)");
	exec ("json.load(hugeout.out,hugewithdate.json)");
	exec ("json.load(flareout.out,flareinstruments.json)");
	exec ("json.load(ins.out,instrumetns.json)");
	exec ("json.load(flareout2.out,flarer.json)");
	exec ("json.load(date.out,dateid.json)");
	exec ("json.load(flareout3.out,flareradial.json)");
	exec ("json.load(date2.out,datecreated.json)");
	exec ("json.load(mis.out,misearables.json)");
	exec ("json.load(flareout4.out,flare.json)");
	exec ("json.load(sciencekeywords.out,science.json)");
	exec ("json.load(huge.out,huge.json)");
	
	
}



if(isset($_GET["q"]))
{

$a=isset($_GET["q"])?$_GET["q"]:'';
$a = preg_replace('/\s+/','+',$a);//unwnated characters removal "a"corresponds to the query

$url="http://localhost:8983/solr/collection1/select?q=".$a."&clavin_location%3A%5B*+TO+*%5D&rows=1000&fl=clavin_location%2Cid%2Cclavin_name%2Cclavin_latitude%2C+clavin_longitude%2Cscience_keywords&wt=json&indent=true"


$jsonIterator = new RecursiveIteratorIterator(
    new RecursiveArrayIterator(json_decode($url, TRUE)),
    RecursiveIteratorIterator::SELF_FIRST);

foreach ($jsonIterator as $key => $val) {
    if(is_array($val)) {
        echo "$key:\n";
    } else {
        echo "$key => $val\n";
    }
}


buildexec();




}

?>