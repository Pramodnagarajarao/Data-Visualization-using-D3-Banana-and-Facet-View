import sys
import json

txt=open("science.json",'r',errors='ignore')


js=json.load(txt)
#print(js)
n=js['response']['numFound']
print(n)
d={}
for x in range(0,n):
	print(js['response']['docs'][x])
	temp=js['response']['docs'][x]['science_keywords']
	for item in temp:
		if item not in d:
			d[item]=1000
		else:
			d[item]=d[item]+1000
txt2=open("flare.json",'w')
txt2.write("{\"name\":\"bubble\",\"children\":[\n")
for item in d:
	txt2.write("{\"name\":\""+item+"\",\"children\":[{\"name\": \""+item+"\",\"size\": \""+str(d[item])+"\"}]},\n")

txt2.close()
