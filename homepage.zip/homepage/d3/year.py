import sys
import json
import os
txt=open("dateid.json",'r',errors='ignore')


js=json.load(txt)
#print(js)
n=js['response']['numFound']
print(n)
dy={}
dm={}
di={}
for x in range(0,n):
	#print(js['response']['docs'][x])
	temp=js['response']['docs'][x]['date_created']
	if temp=='':
		continue
	listw=temp.split(' ')
	#print(listw)
	listw=listw[0].split('-')
	if listw[0]=='2013':
		item=listw[1]
		if item=='01':
			t='Jan'
			if t not in di:
				di[t]=[]
				di[t].append(js['response']['docs'][x]['id'])
			else:	
				di[t].append(js['response']['docs'][x]['id'])
		elif item=='02':
			t='Feb'
			if t not in di:
				di[t]=[]
				di[t].append(js['response']['docs'][x]['id'])
			else:	
				di[t].append(js['response']['docs'][x]['id'])
		elif item=='03':
			t='Mar'
			if t not in di:
				di[t]=[]
				di[t].append(js['response']['docs'][x]['id'])
			else:	
				di[t].append(js['response']['docs'][x]['id'])

		elif item=='04':
			t='Apr'
			if t not in di:
				di[t]=[]
				di[t].append(js['response']['docs'][x]['id'])
			else:	
				di[t].append(js['response']['docs'][x]['id'])
		elif item=='05':
			t='May'
			if t not in di:
				di[t]=[]
				di[t].append(js['response']['docs'][x]['id'])
			else:	
				di[t].append(js['response']['docs'][x]['id'])
		elif item=='06':
			t='Jun'
			if t not in di:
				di[t]=[]
				di[t].append(js['response']['docs'][x]['id'])
			else:	
				di[t].append(js['response']['docs'][x]['id'])
		elif item=='07':
			t='Jul'
			if t not in di:
				di[t]=[]
				di[t].append(js['response']['docs'][x]['id'])
			else:	
				di[t].append(js['response']['docs'][x]['id'])
		elif item=='08':
			t='Aug'
			if t not in di:
				di[t]=[]
				di[t].append(js['response']['docs'][x]['id'])
			else:	
				di[t].append(js['response']['docs'][x]['id'])
		elif item=='09':
			t='Sep'
			if t not in di:
				di[t]=[]
				di[t].append(js['response']['docs'][x]['id'])
			else:	
				di[t].append(js['response']['docs'][x]['id'])
		elif item=='10':
			t='Oct'
			if t not in di:
				di[t]=[]
				di[t].append(js['response']['docs'][x]['id'])
			else:	
				di[t].append(js['response']['docs'][x]['id'])
		elif item=='11':
			t='Nov'
			if t not in di:
				di[t]=[]
				di[t].append(js['response']['docs'][x]['id'])
			else:	
				di[t].append(js['response']['docs'][x]['id'])
		elif item=='12':
			t='Dec'
			if t not in di:
				di[t]=[]
				di[t].append(js['response']['docs'][x]['id'])
			else:	
				di[t].append(js['response']['docs'][x]['id'])
		
	

txt2=open("flarer.json",'w')
txt2.write("{\n\"name\":\"2013\",\n\"children\":[")

for item in di:
	txt2.write("\n{\n\"name\":\""+item+"\",\n\"children\":[\n")
	nn=len(di[item])
	print(nn)
	c=0
	for i in di[item]:
		if c==nn-1:
			txt2.write("\n{\n\"name\":\""+os.path.basename(i)+"\",\"size\":500}\n")
		else:
			txt2.write("\n{\n\"name\":\""+os.path.basename(i)+"\",\"size\":500},\n")
		c=c+1

	txt2.write("]\n},")


txt2.write("]\n}")


txt2.close()
