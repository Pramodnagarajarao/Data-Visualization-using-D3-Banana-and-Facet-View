import sys
import json
import os
txt=open("dateid.json",'r',errors='ignore')


js=json.load(txt)
#print(js)
n=js['response']['numFound']
print(n)
dy={}
dm={}
di={}
for x in range(0,n):
	#print(js['response']['docs'][x])
	temp=js['response']['docs'][x]['date_created']
	if temp=='':
		continue
	listw=temp.split(' ')
	#print(listw)
	listw=listw[0].split('-')
	if listw[1]=='11':
		item=listw[2]
		print(item)
		for y in range(1,32):
			if y<10 and item=="0"+str(y):	
				t="0"+str(y)
				if t not in di:
					di[t]=[]
					di[t].append(js['response']['docs'][x]['id'])
				else:	
					di[t].append(js['response']['docs'][x]['id'])
			elif item==str(y):
				t=str(y)
				if t not in di:
					di[t]=[]
					di[t].append(js['response']['docs'][x]['id'])
				else:	
					di[t].append(js['response']['docs'][x]['id'])
		

txt2=open("flarer303.json",'w')
txt2.write("{\n\"name\":\"Nov\",\n\"children\":[")

for item in di:
	txt2.write("\n{\n\"name\":\""+item+"\",\n\"children\":[\n")
	nn=len(di[item])
	print(nn)
	c=0
	for i in di[item]:
		if c==nn-1:
			txt2.write("\n{\n\"name\":\""+os.path.basename(i)+"\",\"size\":500}\n")
		else:
			txt2.write("\n{\n\"name\":\""+os.path.basename(i)+"\",\"size\":500},\n")
		c=c+1

	txt2.write("]\n},")


txt2.write("]\n}")


txt2.close()
