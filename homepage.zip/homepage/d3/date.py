import sys
import json

txt=open("datecreated.json",'r',errors='ignore')


js=json.load(txt)
#print(js)
n=js['response']['numFound']
print(n)
dy={}
dm={}
for x in range(0,n):
	print(js['response']['docs'][x])
	temp=js['response']['docs'][x]['date_created']
	if temp=='':
		continue
	listw=temp.split(' ')
	print(listw)
	listw=listw[0].split('-')
	if listw[0] not in dy:
		dy[listw[0]]=1
	else:
		dy[listw[0]]=dy[listw[0]]+1
	if listw[1] not in dm:
		dm[listw[1]]=1
	else:
		dm[listw[1]]=dm[listw[1]]+1
txt2=open("data.csv",'w')
txt2.write("year,numberofdocuments")
for item in dy:
	txt2.write("\n"+item+"["+str(dy[item])+"]"+","+str(dy[item]))
txt2.close()

txt2=open("datam.csv",'w')
txt2.write("month,numberofdocuments")
for item in dm:
	if item=='01':
		t='Jan'
	elif item=='02':
		t='Feb'
	elif item=='03':
		t='Mar'
	elif item=='04':
		t='Apr'
	elif item=='05':
		t='May'
	elif item=='06':
		t='Jun'
	elif item=='07':
		t='Jul'
	elif item=='08':
		t='Aug'
	elif item=='09':
		t='Sep'
	elif item=='10':
		t='Oct'
	elif item=='11':
		t='Nov'
	elif item=='12':
		t='Dec'
	

	txt2.write("\n"+t+"["+str(dm[item])+"]"+","+str(dm[item]))
txt2.close()
